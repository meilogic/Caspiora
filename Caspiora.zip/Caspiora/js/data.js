// Caspiora Premium Nuts - Structured Catalog Data

const HERO_SLIDES = [
  {
    id: 'hero-all',
    title: 'The Golden Harvest of Nature',
    subtitle: '100% Hand-Selected Gourmet Nuts & Royal Dry Fruits',
    description: 'Experience the unmatched crunch, buttery richness, and artisan quality of Caspiora. Sourced directly from premier orchards across Goa, California, Chile, and Afghanistan.',
    image: 'assets/images/hero.png',
    badge: '👑 Royal Connoisseur Selection',
    highlights: ['Vacuum Sealed For 100% Freshness', 'Zero Added Preservatives', 'Grade-A Export Quality'],
    ctaText: 'Explore Catalog',
    ctaLink: '#products',
    accentColor: '#e5a93c'
  },
  {
    id: 'hero-cashews',
    title: 'Imperial Cashew Collection',
    subtitle: 'King W180, W240, Roasted, Peri-Peri & Chocolate Varieties',
    description: 'From monumental King Jumbo W180 whole kernels to slow-roasted salted delicacies and fiery Peri-Peri crunch. Discover why Caspiora is the gold standard in cashews.',
    image: 'assets/images/cashews.png',
    badge: '✨ All 8 Cashew Varieties Available',
    highlights: ['W180 King of Cashews', 'Slow Roasted with Himalayan Salt', 'Stone-Ground Dark Chocolate Glazed'],
    ctaText: 'View All Cashews',
    ctaLink: '#products',
    accentColor: '#f5c05b'
  },
  {
    id: 'hero-almonds',
    title: 'California & Kashmiri Mamra Almonds',
    subtitle: 'High-Oil Content & Crisp Golden Heartiness',
    description: 'Packed with natural Vitamin E, essential minerals, and rich crunch. Carefully sun-dried and graded for the purist snackers and daily nutrition.',
    image: 'assets/images/almonds.png',
    badge: '🌿 Mamra & California Grade-A',
    highlights: ['Up to 50% Natural Oil in Mamra', 'Unpasteurized & 100% Natural', 'Heart-Healthy Superfood'],
    ctaText: 'Shop Almonds',
    ctaLink: '#products',
    accentColor: '#df8e3f'
  },
  {
    id: 'hero-pista',
    title: 'Naturally Smiling Emerald Pistachios',
    subtitle: 'Slow-Roasted with Pink Himalayan Sea Salt',
    description: 'Vibrant green kernels naturally burst open on the tree under sunny orchards. Roasted to crisp perfection with just the right touch of pure mineral salt.',
    image: 'assets/images/pista.png',
    badge: '🌱 100% Tree-Ripened & Opened',
    highlights: ['Naturally Opened Shells', 'Rich in Antioxidants & Lutein', 'Pure Kernel & In-Shell Choices'],
    ctaText: 'Discover Pistachios',
    ctaLink: '#products',
    accentColor: '#58b368'
  },
  {
    id: 'hero-walnuts',
    title: 'Chilean Extra Light Walnut Halves',
    subtitle: 'Snow-White Butterfly Halves with Brain-Boosting Omega-3',
    description: 'Crisp, buttery, and remarkably free of bitterness. Sourced from the Andean foothills of Chile, vacuum sealed instantly to preserve delicate natural omega oils.',
    image: 'assets/images/walnuts.png',
    badge: '🧠 80%+ Extra Light Halves',
    highlights: ['Rich in Plant-Based Omega-3 ALA', 'Crisp Buttery Flavor', 'No Bitter Tannin Aftertaste'],
    ctaText: 'Shop Walnuts',
    ctaLink: '#products',
    accentColor: '#b87d4b'
  },
  {
    id: 'hero-figs',
    title: 'Royal Afghan & Turkish Honey Figs',
    subtitle: 'Succulent, Tender Anjeer Bursting with Natural Honey Sweetness',
    description: 'Plump golden sun-dried figs loaded with dietary fiber, iron, and calcium. Tender to bite, sweet on the palate, and ideal for holistic vitality.',
    image: 'assets/images/figs.png',
    badge: '🍯 Naturally Sun-Dried Anjeer',
    highlights: ['Zero Added Sugar', 'Rich in Dietary Fiber & Iron', 'Soft & Chewy Gourmet Quality'],
    ctaText: 'Explore Figs',
    ctaLink: '#products',
    accentColor: '#c76e48'
  }
];

const PRODUCTS = [
  // --- CASHEW VARIETIES ---
  {
    id: 'cashew-w180',
    category: 'cashews',
    name: 'Caspiora W180 King Jumbo Cashews',
    tagline: 'The King of Cashews — Monumental Size & Creamy Crunch',
    image: 'assets/images/cashews.png',
    grade: 'W-180 King Jumbo',
    origin: 'Mangalore & Goa Orchards',
    rating: 5.0,
    reviewsCount: 142,
    badge: 'Bestseller',
    basePrice250g: 480,
    basePrice500g: 920,
    basePrice1kg: 1780,
    basePrice5kg: 8400,
    description: 'Cashew W180 is famously crowned the "King of Cashews". It represents the largest, rarest size with only 160-180 kernels per pound. Exceptionally sweet, buttery, and pristine white.',
    specs: {
      countPerPound: '160 - 180 nuts',
      moisture: '< 5%',
      processing: 'Nitrogen vacuum flushed',
      shelfLife: '12 Months'
    },
    nutrition: { calories: '553 kcal', protein: '18.2g', healthyFats: '43.8g', carbs: '30.1g' }
  },
  {
    id: 'cashew-w240',
    category: 'cashews',
    name: 'Caspiora W240 Royal Jumbo Cashews',
    tagline: 'Substantial Jumbo Kernels, Silky Texture & Balanced Sweetness',
    image: 'assets/images/cashews.png',
    grade: 'W-240 Royal Jumbo',
    origin: 'Goan Coastal Belt',
    rating: 4.9,
    reviewsCount: 98,
    badge: 'Popular',
    basePrice250g: 390,
    basePrice500g: 750,
    basePrice1kg: 1450,
    basePrice5kg: 6850,
    description: 'A prized selection offering remarkable kernel size and luxurious density. Popular for premium snacking, royal festive platters, and gift boxes.',
    specs: {
      countPerPound: '220 - 240 nuts',
      moisture: '< 5%',
      processing: 'Whole White Kernels',
      shelfLife: '12 Months'
    },
    nutrition: { calories: '553 kcal', protein: '18.2g', healthyFats: '43.8g', carbs: '30.1g' }
  },
  {
    id: 'cashew-w320',
    category: 'cashews',
    name: 'Caspiora W320 Classic Whole Cashews',
    tagline: 'World-Standard Whole Cashew Kernels for Daily Snacking',
    image: 'assets/images/cashews.png',
    grade: 'W-320 Classic Whole',
    origin: 'Kerala & Coastal Karnataka',
    rating: 4.8,
    reviewsCount: 215,
    badge: 'Daily Favorite',
    basePrice250g: 310,
    basePrice500g: 590,
    basePrice1kg: 1150,
    basePrice5kg: 5400,
    description: 'The universally recognized gold standard for premium cashews. Crispy, uniform in shape, and ideal for health-conscious daily breakfast mixes and culinary masterpieces.',
    specs: {
      countPerPound: '300 - 320 nuts',
      moisture: '< 5%',
      processing: 'Whole Crisp Kernels',
      shelfLife: '12 Months'
    },
    nutrition: { calories: '553 kcal', protein: '18.2g', healthyFats: '43.8g', carbs: '30.1g' }
  },
  {
    id: 'cashew-roasted-salted',
    category: 'cashews',
    name: 'Slow-Roasted Pink Himalayan Salt Cashews',
    tagline: 'Dry-Roasted Without Oil, Dusted in Pure Himalayan Rock Salt',
    image: 'assets/images/cashews.png',
    grade: 'Gourmet Roasted W240',
    origin: 'Artisan Roast House',
    rating: 4.9,
    reviewsCount: 178,
    badge: 'Savory Delight',
    basePrice250g: 420,
    basePrice500g: 810,
    basePrice1kg: 1560,
    basePrice5kg: 7300,
    description: 'Handcrafted in micro-batches. Kernels are gently drum-roasted at low temperatures to lock in crunch, then dusted with pristine pink Himalayan crystal salt.',
    specs: {
      countPerPound: 'W240 Roasted',
      moisture: '< 3.5%',
      processing: 'Zero Oil Drum Roast',
      shelfLife: '9 Months'
    },
    nutrition: { calories: '570 kcal', protein: '17.5g', healthyFats: '45.1g', carbs: '28.9g' }
  },
  {
    id: 'cashew-peri-peri',
    category: 'cashews',
    name: 'Fiery Peri-Peri & Smoked Chili Cashews',
    tagline: 'Tangy African Bird’s Eye Chili & Smoked Paprika Infusion',
    image: 'assets/images/cashews.png',
    grade: 'Spiced W240 Whole',
    origin: 'Gourmet Kitchen',
    rating: 4.9,
    reviewsCount: 89,
    badge: 'Spicy Hit',
    basePrice250g: 430,
    basePrice500g: 830,
    basePrice1kg: 1600,
    basePrice5kg: 7500,
    description: 'An explosion of bold spice and citrus zest. Whole roasted cashews tossed in authentic Peri-Peri blend, garlic hints, and cracked black pepper.',
    specs: {
      countPerPound: 'W240 Spiced',
      moisture: '< 3.8%',
      processing: 'Artisan Coated',
      shelfLife: '9 Months'
    },
    nutrition: { calories: '564 kcal', protein: '17.0g', healthyFats: '44.5g', carbs: '31.2g' }
  },
  {
    id: 'cashew-splits',
    category: 'cashews',
    name: 'Premium Split Cashews (2-Piece Tukda)',
    tagline: 'Pure Halved White Kernels for Gravies, Sweets & Cooking',
    image: 'assets/images/cashews.png',
    grade: 'Split Kernels (JH/Tukda)',
    origin: 'Goan Coastal Belt',
    rating: 4.7,
    reviewsCount: 64,
    badge: 'Chef Choice',
    basePrice250g: 260,
    basePrice500g: 490,
    basePrice1kg: 950,
    basePrice5kg: 4450,
    description: 'Naturally separated clean cashew halves. Unbeatable value for confectionery, kaju katli, biryani garnishes, and velvety rich cashew cream gravies.',
    specs: {
      countPerPound: 'Clean Split Halves',
      moisture: '< 5%',
      processing: 'Mechanical Grade Cleaned',
      shelfLife: '12 Months'
    },
    nutrition: { calories: '553 kcal', protein: '18.2g', healthyFats: '43.8g', carbs: '30.1g' }
  },
  {
    id: 'cashew-dark-chocolate',
    category: 'cashews',
    name: 'Artisan Dark Chocolate Glazed Cashews',
    tagline: '70% Belgian Single-Origin Cocoa Enrobed Over Whole Cashews',
    image: 'assets/images/cashews.png',
    grade: 'Confectionery Reserve',
    origin: 'Handcrafted Chocolaterie',
    rating: 5.0,
    reviewsCount: 112,
    badge: 'Indulgent',
    basePrice250g: 490,
    basePrice500g: 940,
    basePrice1kg: 1820,
    basePrice5kg: 8600,
    description: 'A decadent harmony of crunchy roasted cashews immersed in smooth 70% dark chocolate with notes of roasted vanilla and sea salt.',
    specs: {
      countPerPound: 'Chocolate Coated',
      moisture: '< 2.5%',
      processing: 'Cold Pan Enrobed',
      shelfLife: '6 Months'
    },
    nutrition: { calories: '585 kcal', protein: '12.4g', healthyFats: '42.1g', carbs: '44.8g' }
  },

  // --- ALMOND VARIETIES ---
  {
    id: 'almond-california',
    category: 'almonds',
    name: 'California Nonpareil Extra No.1 Almonds',
    tagline: 'Sweet, Light-Skinned & Perfectly Oval Crisp Kernels',
    image: 'assets/images/almonds.png',
    grade: 'Nonpareil Supreme 23/25',
    origin: 'Central Valley, California',
    rating: 4.9,
    reviewsCount: 310,
    badge: 'Top Pick',
    basePrice250g: 320,
    basePrice500g: 610,
    basePrice1kg: 1180,
    basePrice5kg: 5550,
    description: 'The world benchmark for appearance, sweetness, and uniform crunch. Perfect for soaking overnight, snacking, almond milk, and baking.',
    specs: {
      countPerPound: '23 - 25 per ounce',
      moisture: '< 5.5%',
      processing: 'Sun-Cured & Cleaned',
      shelfLife: '12 Months'
    },
    nutrition: { calories: '579 kcal', protein: '21.2g', healthyFats: '49.9g', carbs: '21.6g' }
  },
  {
    id: 'almond-mamra',
    category: 'almonds',
    name: 'Original Kashmiri Mamra Badam (High-Oil)',
    tagline: 'Connoisseur Almond with up to 50% Natural Oil Content',
    image: 'assets/images/almonds.png',
    grade: 'Organic Mamra Reserve',
    origin: 'Kashmir Valley & Iran',
    rating: 5.0,
    reviewsCount: 95,
    badge: 'Rare Heritage',
    basePrice250g: 780,
    basePrice500g: 1520,
    basePrice1kg: 2950,
    basePrice5kg: 13900,
    description: 'Distinctive curved boat shape with natural ridges and unmatched concentration of natural almond oil. Revered in traditional wellness for mental focus and energy.',
    specs: {
      countPerPound: 'Wild Mamra Harvest',
      moisture: '< 4%',
      processing: 'Raw Unpasteurized',
      shelfLife: '12 Months'
    },
    nutrition: { calories: '612 kcal', protein: '22.8g', healthyFats: '54.1g', carbs: '18.4g' }
  },
  {
    id: 'almond-roasted-salted',
    category: 'almonds',
    name: 'Slow Roasted & Salted California Almonds',
    tagline: 'Crisp Smoke-Kissed Crunch with Delicate Sea Salt',
    image: 'assets/images/almonds.png',
    grade: 'Gourmet Roasted',
    origin: 'Artisan Roast House',
    rating: 4.8,
    reviewsCount: 134,
    badge: 'Snack Hit',
    basePrice250g: 360,
    basePrice500g: 690,
    basePrice1kg: 1320,
    basePrice5kg: 6200,
    description: 'Dry roasted to activate the aromatic roasted nut oils, dusted with mineral-rich sea salt. A satisfying protein-packed powerhouse snack.',
    specs: {
      countPerPound: 'Uniform Roast',
      moisture: '< 3%',
      processing: 'Zero Oil Roasting',
      shelfLife: '9 Months'
    },
    nutrition: { calories: '590 kcal', protein: '21.0g', healthyFats: '51.2g', carbs: '20.1g' }
  },

  // --- PISTACHIO VARIETIES ---
  {
    id: 'pista-roasted-salted',
    category: 'pista',
    name: 'Royal Iranian Jumbo Roasted & Salted Pistachios',
    tagline: 'Naturally Opened In-Shell Pistachios with Emerald Kernels',
    image: 'assets/images/pista.png',
    grade: 'Akbari Jumbo 20/22',
    origin: 'Rafsanjan, Iran',
    rating: 4.9,
    reviewsCount: 224,
    badge: 'Fan Favorite',
    basePrice250g: 395,
    basePrice500g: 760,
    basePrice1kg: 1470,
    basePrice5kg: 6950,
    description: 'Long, elongated royal pistachios that naturally smile open on the branch. Roasted slowly with crystal salt to create a crunchy, vibrant green delicacy.',
    specs: {
      countPerPound: '20 - 22 per ounce',
      moisture: '< 3.5%',
      processing: 'In-Shell Dry Roasted',
      shelfLife: '12 Months'
    },
    nutrition: { calories: '562 kcal', protein: '20.3g', healthyFats: '45.3g', carbs: '27.5g' }
  },
  {
    id: 'pista-raw-kernels',
    category: 'pista',
    name: 'Vibrant Green Pistachio Kernels (Pista Magaz)',
    tagline: '100% Shell-Free Raw Green Kernels for Garnishing & Desserts',
    image: 'assets/images/pista.png',
    grade: 'Super Green Peeled',
    origin: 'California Orchards',
    rating: 4.9,
    reviewsCount: 88,
    badge: 'Pure Kernels',
    basePrice250g: 580,
    basePrice500g: 1120,
    basePrice1kg: 2180,
    basePrice5kg: 10200,
    description: 'Carefully deshelled, unroasted whole green kernels. Intense natural aroma and vivid color for halwas, baklava, ice creams, and salads.',
    specs: {
      countPerPound: 'Pure Kernels Shell-free',
      moisture: '< 4.5%',
      processing: 'Raw Unsalted',
      shelfLife: '9 Months'
    },
    nutrition: { calories: '567 kcal', protein: '20.9g', healthyFats: '45.8g', carbs: '27.2g' }
  },

  // --- WALNUT VARIETIES ---
  {
    id: 'walnut-chilean-halves',
    category: 'walnut',
    name: 'Chilean Extra Light Walnut Halves',
    tagline: 'Snow-White Butterfly Halves — Sweet, Crisp & Bitterness-Free',
    image: 'assets/images/walnuts.png',
    grade: 'Extra Light Chandler 80%+',
    origin: 'Central Valley, Chile',
    rating: 5.0,
    reviewsCount: 167,
    badge: 'Superfood',
    basePrice250g: 440,
    basePrice500g: 850,
    basePrice1kg: 1640,
    basePrice5kg: 7750,
    description: 'Famous for their remarkably bright color, tender crispness, and complete absence of harsh tannins. Packed with vital Alpha-Linolenic Acid (ALA Omega-3).',
    specs: {
      countPerPound: '80% Extra Light Halves',
      moisture: '< 4.5%',
      processing: 'Vacuum Flushed',
      shelfLife: '12 Months'
    },
    nutrition: { calories: '654 kcal', protein: '15.2g', healthyFats: '65.2g', carbs: '13.7g' }
  },
  {
    id: 'walnut-kashmir-organic',
    category: 'walnut',
    name: 'Organic Kashmiri Walnut Kernels (Light Amber)',
    tagline: 'Naturally Grown in Himalayan Foothills — Dense Rich Nutty Oil',
    image: 'assets/images/walnuts.png',
    grade: 'Himalayan Organic Kernels',
    origin: 'Kupwara, Kashmir',
    rating: 4.8,
    reviewsCount: 92,
    badge: 'Organic',
    basePrice250g: 380,
    basePrice500g: 720,
    basePrice1kg: 1390,
    basePrice5kg: 6550,
    description: 'Hand-cracked kernels harvested from heritage walnut groves without chemical fertilizers. Packed with pure antioxidant goodness.',
    specs: {
      countPerPound: 'Mixed Halves & Quarters',
      moisture: '< 5%',
      processing: 'Hand Cracked & Cleaned',
      shelfLife: '9 Months'
    },
    nutrition: { calories: '650 kcal', protein: '15.0g', healthyFats: '64.8g', carbs: '14.1g' }
  },

  // --- FIG (ANJEER) VARIETIES ---
  {
    id: 'fig-afghan-jumbo',
    category: 'fig',
    name: 'Royal Afghan Jumbo Dried Figs (Anjeer)',
    tagline: 'Plump, Golden Amber Figs with Natural Honeyed Seeds',
    image: 'assets/images/figs.png',
    grade: 'Jumbo No.1 Selection',
    origin: 'Kandahar & Herat, Afghanistan',
    rating: 5.0,
    reviewsCount: 189,
    badge: 'Royal Grade',
    basePrice250g: 460,
    basePrice500g: 890,
    basePrice1kg: 1720,
    basePrice5kg: 8100,
    description: 'Sun-dried under the desert sun. These jumbo figs possess soft chewy flesh with delicate crunchy seeds and intense natural fruit sweetness with zero added sucrose.',
    specs: {
      countPerPound: 'Jumbo Size 40-50/kg',
      moisture: '< 18%',
      processing: 'Sundried Naturally',
      shelfLife: '12 Months'
    },
    nutrition: { calories: '249 kcal', protein: '3.3g', healthyFats: '0.9g', carbs: '63.9g' }
  },
  {
    id: 'fig-turkish-organic',
    category: 'fig',
    name: 'Organic Turkish Soft Dried Mountain Figs',
    tagline: 'Thin-Skinned, Melt-in-Mouth Figs from Izmir Valleys',
    image: 'assets/images/figs.png',
    grade: 'Lerida Organic Grade A',
    origin: 'Aydin & Izmir, Turkey',
    rating: 4.9,
    reviewsCount: 114,
    badge: 'Pure Organic',
    basePrice250g: 410,
    basePrice500g: 790,
    basePrice1kg: 1520,
    basePrice5kg: 7150,
    description: 'Renowned for extremely tender, thin skins and luscious syrup-like interior. Rich in iron, potassium, and digestive prebiotic fibers.',
    specs: {
      countPerPound: 'Lerida Flattened Shape',
      moisture: '< 20%',
      processing: 'Unbleached & Unsulphured',
      shelfLife: '10 Months'
    },
    nutrition: { calories: '254 kcal', protein: '3.1g', healthyFats: '1.2g', carbs: '64.5g' }
  }
];

const WHOLESALE_TIERS = [
  { minKg: 1, maxKg: 4, discountPercent: 0, tierName: 'Retail Explorer', badge: 'Standard Rate', freeDelivery: false },
  { minKg: 5, maxKg: 19, discountPercent: 12, tierName: 'Bulk Family & Baker', badge: '12% OFF', freeDelivery: true },
  { minKg: 20, maxKg: 49, discountPercent: 20, tierName: 'Semi-Wholesale & Cafe', badge: '20% OFF', freeDelivery: true },
  { minKg: 50, maxKg: 500, discountPercent: 28, tierName: 'Commercial Master Carton', badge: '28% OFF + B2B Invoicing', freeDelivery: true }
];

const CASHEW_GRADE_GUIDE = [
  {
    grade: 'W-180',
    alias: 'The King of Cashews',
    count: '160 - 180 / lb',
    appearance: 'Monumental jumbo size, pristine cream ivory, highest prestige',
    bestFor: 'Luxury gifting, executive executive trays, connoisseur snacking',
    premiumIndex: '★★★★★'
  },
  {
    grade: 'W-240',
    alias: 'Royal Jumbo',
    count: '220 - 240 / lb',
    appearance: 'Generous large kernel, elegant curvature, high oil richness',
    bestFor: 'Festive celebrations, premium daily nutrition, gourmet roasting',
    premiumIndex: '★★★★☆'
  },
  {
    grade: 'W-320',
    alias: 'Classic Standard',
    count: '300 - 320 / lb',
    appearance: 'Medium uniform whole, crispy snap, world market favorite',
    bestFor: 'Daily fitness snacking, breakfast bowls, family consumption',
    premiumIndex: '★★★★☆'
  },
  {
    grade: 'JH / Tukda',
    alias: 'Split Halves (2-Piece)',
    count: 'Clean halves',
    appearance: 'Intact halved kernels, zero dust, uniform split',
    bestFor: 'Kaju Katli, cashew butter, rich gravies, confectionery baking',
    premiumIndex: '★★★☆☆'
  }
];

const TESTIMONIALS = [
  {
    name: 'Chef Raghavendra Rao',
    role: 'Executive Pastry Chef, The Grand Pavilion',
    text: 'We switched to Caspiora W180 King Cashews and Chilean Extra Light Walnuts for our five-star desserts. The freshness and absence of bitterness are unmatched. Truly world-class quality.',
    rating: 5,
    location: 'Bengaluru'
  },
  {
    name: 'Ananya Deshmukh',
    role: 'Nutrition & Wellness Consultant',
    text: 'Caspiora Mamra Almonds and Afghan Figs are a staple I recommend to all my high-performance clients. The nitrogen vacuum packaging keeps them as fresh as the day they were harvested.',
    rating: 5,
    location: 'Mumbai'
  },
  {
    name: 'Vikram Sethi',
    role: 'Wholesale Buyer & Gift Concierge',
    text: 'Placed a 150 kg corporate festive order for Caspiora luxury nut hampers. Every single box arrived in pristine condition, laser-fresh, and our corporate clients were absolutely blown away.',
    rating: 5,
    location: 'New Delhi'
  }
];

const FAQS = [
  {
    q: 'What makes Caspiora cashews different from ordinary supermarket nuts?',
    a: 'Caspiora cashews are hand-graded under stringent ISO & FSSAI standards. We only select Grade-A unblemished whole kernels, vacuum seal them with food-grade nitrogen within 48 hours of shelling, ensuring zero moisture absorption, crispness, and natural sweet creaminess.'
  },
  {
    q: 'What do the cashew grades like W180, W240, and W320 mean?',
    a: '"W" stands for "White Whole". The number designates how many cashew kernels weigh exactly one pound (approx. 454g). Lower numbers mean larger, heavier individual nuts. W180 is the biggest King size, W240 is Royal Jumbo, and W320 is standard medium.'
  },
  {
    q: 'Do you offer bulk wholesale pricing for cafes, caterers, and corporate gifting?',
    a: 'Yes! We specialize in wholesale master cartons (10kg, 20kg tins, and 50kg crates) with discounts up to 28%, GST-compliant tax invoicing, customized corporate branding, and expedited refrigerated transit.'
  },
  {
    q: 'How should I store Caspiora nuts and dry fruits for maximum shelf life?',
    a: 'Keep unsealed packs in an airtight glass container in a cool, dry place away from sunlight. For prolonged freshness beyond 3 months, refrigerate almonds, pistachios, and walnuts to preserve their natural heart-healthy oils.'
  },
  {
    q: 'How fast do you dispatch orders?',
    a: 'Retail orders are dispatched within 24 hours via express air couriers (2-3 business days delivery). Wholesale and bulk shipments are scheduled through insured freight with tracking provided immediately.'
  }
];
