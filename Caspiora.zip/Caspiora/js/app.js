// ==========================================================================
// CASPIORA PREMIUM NUTS - APP INTERACTIVE CONTROLLER
// ==========================================================================

document.addEventListener('DOMContentLoaded', () => {
    // Application State
    const state = {
        currentHeroSlide: 0,
        heroAutoPlayInterval: null,
        heroAutoPlayPlaying: true,
        flashSpeeds: [
            { name: 'Radiant (7s)', duration: '7s' },
            { name: 'Dynamic (4s)', duration: '4s' },
            { name: 'Gentle (10s)', duration: '10s' }
        ],
        currentFlashSpeedIndex: 0,
        selectedCategory: 'all',
        selectedSizes: {}, // { [productId]: '500g' }
        cart: [],
        bulkCalc: {
            productId: 'cashew-w180',
            weightKg: 10,
            packaging: 'vacuum-pouches'
        }
    };

    // Initialize selected pack sizes default to '500g'
    PRODUCTS.forEach(p => {
        state.selectedSizes[p.id] = '500g';
    });

    // Load existing cart from localStorage if present
    try {
        const savedCart = localStorage.getItem('caspiora_cart');
        if (savedCart) state.cart = JSON.parse(savedCart);
    } catch (e) {
        console.error('LocalStorage unavailable', e);
    }

    // ========================================================================
    // 1. HERO SLIDER & FLASH MOVING CONTROLLER
    // ========================================================================
    const heroBadge = document.getElementById('heroBadge');
    const heroTitle = document.getElementById('heroTitle');
    const heroSubtitle = document.getElementById('heroSubtitle');
    const heroDesc = document.getElementById('heroDesc');
    const heroHighlights = document.getElementById('heroHighlights');
    const heroMainImg = document.getElementById('heroMainImg');
    const heroIndicators = document.getElementById('heroIndicators');
    const heroImageWrapper = document.getElementById('heroImageWrapper');
    const flashLightSweep = document.getElementById('flashLightSweep');
    const flashSpeedToggle = document.getElementById('flashSpeedToggle');
    const heroAutoPlayToggle = document.getElementById('heroAutoPlayToggle');

    // Render indicators
    function renderHeroIndicators() {
        if (!heroIndicators) return;
        heroIndicators.innerHTML = HERO_SLIDES.map((slide, idx) => `
      <div class="indicator-dot ${idx === state.currentHeroSlide ? 'active' : ''}" data-slide="${idx}" title="${slide.title}"></div>
    `).join('');

        heroIndicators.querySelectorAll('.indicator-dot').forEach(dot => {
            dot.addEventListener('click', (e) => {
                const slideIndex = parseInt(e.target.dataset.slide, 10);
                goToHeroSlide(slideIndex);
            });
        });
    }

    function goToHeroSlide(index) {
        state.currentHeroSlide = index;
        const slide = HERO_SLIDES[index];
        if (!slide) return;

        // Smooth transition
        if (heroMainImg) {
            heroMainImg.style.opacity = '0.3';
            heroMainImg.style.transform = 'scale(0.96)';
        }

        setTimeout(() => {
            if (heroBadge) heroBadge.innerHTML = `<i class="fa-solid fa-crown"></i> <span>${slide.badge}</span>`;
            if (heroTitle) heroTitle.innerHTML = `${slide.title.replace(' ', ' <br><span>')}</span>`;
            if (heroSubtitle) heroSubtitle.textContent = slide.subtitle;
            if (heroDesc) heroDesc.textContent = slide.description;

            if (heroHighlights) {
                heroHighlights.innerHTML = slide.highlights.map(hl => `
          <div class="highlight-item"><i class="fa-solid fa-circle-check icon"></i> ${hl}</div>
        `).join('');
            }

            if (heroMainImg) {
                heroMainImg.onload = () => {
                    heroMainImg.style.opacity = '1';
                    heroMainImg.style.transform = 'scale(1)';
                };
                heroMainImg.onerror = () => {
                    if (heroMainImg.src.endsWith('.png')) {
                        heroMainImg.src = heroMainImg.src.replace('.png', '.jpg');
                    }
                    heroMainImg.style.opacity = '1';
                    heroMainImg.style.transform = 'scale(1)';
                };
                heroMainImg.src = slide.image;
                heroMainImg.alt = slide.title;
                if (heroMainImg.complete && heroMainImg.naturalWidth > 0) {
                    heroMainImg.style.opacity = '1';
                    heroMainImg.style.transform = 'scale(1)';
                }
            }

            // Update indicator dots
            document.querySelectorAll('.indicator-dot').forEach((d, i) => {
                d.classList.toggle('active', i === state.currentHeroSlide);
            });
        }, 200);
    }

    function startHeroAutoPlay() {
        stopHeroAutoPlay();
        state.heroAutoPlayInterval = setInterval(() => {
            const nextSlide = (state.currentHeroSlide + 1) % HERO_SLIDES.length;
            goToHeroSlide(nextSlide);
        }, 5500);
    }

    function stopHeroAutoPlay() {
        if (state.heroAutoPlayInterval) {
            clearInterval(state.heroAutoPlayInterval);
            state.heroAutoPlayInterval = null;
        }
    }

    // Toggle flash speed
    if (flashSpeedToggle && flashLightSweep) {
        flashSpeedToggle.addEventListener('click', () => {
            state.currentFlashSpeedIndex = (state.currentFlashSpeedIndex + 1) % state.flashSpeeds.length;
            const speed = state.flashSpeeds[state.currentFlashSpeedIndex];
            flashSpeedToggle.textContent = `Speed: ${speed.name}`;
            flashLightSweep.style.animationDuration = speed.duration;
            showToast(`Flash beam speed adjusted to ${speed.name}`);
        });
    }

    // Toggle auto play
    if (heroAutoPlayToggle) {
        heroAutoPlayToggle.addEventListener('click', () => {
            state.heroAutoPlayPlaying = !state.heroAutoPlayPlaying;
            if (state.heroAutoPlayPlaying) {
                startHeroAutoPlay();
                heroAutoPlayToggle.innerHTML = '<i class="fa-solid fa-pause"></i> Pause';
                showToast('Hero showcase auto-play resumed');
            } else {
                stopHeroAutoPlay();
                heroAutoPlayToggle.innerHTML = '<i class="fa-solid fa-play"></i> Play';
                showToast('Hero showcase paused');
            }
        });
    }

    // 3D Parallax Tilt Effect on Hero Image Wrapper
    if (heroImageWrapper) {
        heroImageWrapper.addEventListener('mousemove', (e) => {
            const rect = heroImageWrapper.getBoundingClientRect();
            const x = e.clientX - rect.left - rect.width / 2;
            const y = e.clientY - rect.top - rect.height / 2;
            const rotateX = (-y / rect.height) * 16;
            const rotateY = (x / rect.width) * 16;
            heroImageWrapper.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-6px)`;
        });

        heroImageWrapper.addEventListener('mouseleave', () => {
            heroImageWrapper.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) translateY(0)';
        });
    }

    if (heroMainImg) {
        heroMainImg.addEventListener('error', function() {
            if (this.src.endsWith('.png')) {
                this.src = this.src.replace('.png', '.jpg');
            }
        });
    }

    renderHeroIndicators();
    startHeroAutoPlay();

    // ========================================================================
    // 2. CASHEW GRADE SPOTLIGHT GUIDE
    // ========================================================================
    const cashewGradeGrid = document.getElementById('cashewGradeGrid');
    if (cashewGradeGrid && typeof CASHEW_GRADE_GUIDE !== 'undefined') {
        cashewGradeGrid.innerHTML = CASHEW_GRADE_GUIDE.map(g => `
      <div class="grade-item-card">
        <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:8px;">
          <h4 class="grade-title">${g.grade}</h4>
          <span style="color:var(--color-gold); font-size:0.85rem;">${g.premiumIndex}</span>
        </div>
        <div class="grade-alias">${g.alias}</div>
        <p class="grade-meta"><strong>Kernel Count:</strong> ${g.count}</p>
        <p class="grade-meta"><strong>Appearance:</strong> ${g.appearance}</p>
        <p class="grade-meta" style="color:var(--color-gold-light); margin-top:8px;"><strong>Best For:</strong> ${g.bestFor}</p>
      </div>
    `).join('');
    }

    // ========================================================================
    // 3. PRODUCT CATALOG RENDERING & FILTERING
    // ========================================================================
    const productsGrid = document.getElementById('productsGrid');
    const filterTabs = document.getElementById('productFilterTabs');

    function getPriceForProduct(product, size) {
        switch (size) {
            case '250g': return product.basePrice250g;
            case '500g': return product.basePrice500g;
            case '1kg': return product.basePrice1kg;
            case '5kg': return product.basePrice5kg;
            default: return product.basePrice500g;
        }
    }

    function renderProducts() {
        if (!productsGrid) return;

        const filtered = state.selectedCategory === 'all'
            ? PRODUCTS
            : PRODUCTS.filter(p => p.category === state.selectedCategory);

        if (filtered.length === 0) {
            productsGrid.innerHTML = `
        <div style="grid-column: 1 / -1; text-align:center; padding:50px; color:#8c9e94;">
          <i class="fa-solid fa-box-open" style="font-size:3rem; margin-bottom:12px; display:block;"></i>
          No products found in this category.
        </div>
      `;
            return;
        }

        productsGrid.innerHTML = filtered.map(product => {
            const currentSize = state.selectedSizes[product.id] || '500g';
            const currentPrice = getPriceForProduct(product, currentSize);

            return `
        <article class="product-card" data-product-id="${product.id}">
          <div class="product-thumb-box">
            <span class="product-badge-flag">${product.badge}</span>
            <img src="${product.image}" alt="${product.name}" class="product-thumb-img" loading="lazy" onerror="this.onerror=null; if(this.src.endsWith('.png')) this.src=this.src.replace('.png','.jpg');">
            <button class="quick-view-overlay-btn" data-quickview-id="${product.id}">
              <i class="fa-regular fa-eye"></i> Quick View
            </button>
          </div>

          <div class="product-body">
            <div class="product-meta-row">
              <span style="color:var(--color-gold);"><i class="fa-solid fa-location-dot"></i> ${product.origin}</span>
              <div class="product-rating">
                <i class="fa-solid fa-star"></i>
                <span>${product.rating}</span>
                <span style="color:#8fa59a;">(${product.reviewsCount})</span>
              </div>
            </div>

            <h3 class="product-card-title">${product.name}</h3>
            <p class="product-card-tagline">${product.tagline}</p>

            <!-- Pack Size Selector -->
            <div style="font-size:0.75rem; color:#8fa59a; margin-bottom:6px;">Select Package Size:</div>
            <div class="pack-size-selector">
              <button class="size-pill ${currentSize === '250g' ? 'active' : ''}" data-product="${product.id}" data-size="250g">250g</button>
              <button class="size-pill ${currentSize === '500g' ? 'active' : ''}" data-product="${product.id}" data-size="500g">500g</button>
              <button class="size-pill ${currentSize === '1kg' ? 'active' : ''}" data-product="${product.id}" data-size="1kg">1 kg</button>
              <button class="size-pill ${currentSize === '5kg' ? 'active' : ''}" data-product="${product.id}" data-size="5kg">5 kg Box</button>
            </div>

            <div class="product-footer-row">
              <div class="price-display-box">
                <span class="price-label">Price (${currentSize})</span>
                <span class="current-price" id="price-val-${product.id}">₹${currentPrice.toLocaleString('en-IN')}</span>
              </div>

              <button class="add-cart-btn" data-addcart-id="${product.id}">
                <i class="fa-solid fa-plus"></i> Add
              </button>
            </div>
          </div>
        </article>
      `;
        }).join('');

        attachProductEvents();
    }

    function attachProductEvents() {
        // Pack size buttons
        document.querySelectorAll('.size-pill').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const prodId = e.currentTarget.dataset.product;
                const size = e.currentTarget.dataset.size;
                state.selectedSizes[prodId] = size;

                // Update active class on siblings
                const parent = e.currentTarget.closest('.pack-size-selector');
                parent.querySelectorAll('.size-pill').forEach(p => p.classList.remove('active'));
                e.currentTarget.classList.add('active');

                // Update price display
                const product = PRODUCTS.find(p => p.id === prodId);
                if (product) {
                    const priceEl = document.getElementById(`price-val-${prodId}`);
                    if (priceEl) {
                        priceEl.textContent = `₹${getPriceForProduct(product, size).toLocaleString('en-IN')}`;
                    }
                }
            });
        });

        // Add to cart buttons
        document.querySelectorAll('[data-addcart-id]').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const prodId = e.currentTarget.dataset.addcartId;
                const product = PRODUCTS.find(p => p.id === prodId);
                if (product) {
                    const size = state.selectedSizes[prodId] || '500g';
                    addToCart(product, size);
                }
            });
        });

        // Quick view buttons
        document.querySelectorAll('[data-quickview-id]').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const prodId = e.currentTarget.dataset.quickviewId;
                const product = PRODUCTS.find(p => p.id === prodId);
                if (product) openQuickViewModal(product);
            });
        });
    }

    // Filter tabs click
    if (filterTabs) {
        filterTabs.querySelectorAll('.filter-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                filterTabs.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
                e.currentTarget.classList.add('active');
                state.selectedCategory = e.currentTarget.dataset.category;
                renderProducts();
            });
        });
    }

    renderProducts();

    // ========================================================================
    // 4. BULK WHOLESALE PRICING CALCULATOR
    // ========================================================================
    const calcProductSelect = document.getElementById('calcProductSelect');
    const calcWeightSlider = document.getElementById('calcWeightSlider');
    const calcWeightDisplay = document.getElementById('calcWeightDisplay');
    const calcPackagingSelect = document.getElementById('calcPackagingSelect');
    const calcTierBadge = document.getElementById('calcTierBadge');
    const calcSelectedName = document.getElementById('calcSelectedName');
    const calcBaseRate = document.getElementById('calcBaseRate');
    const calcTotalKg = document.getElementById('calcTotalKg');
    const calcDiscountRate = document.getElementById('calcDiscountRate');
    const calcTotalSavings = document.getElementById('calcTotalSavings');
    const calcFreightStatus = document.getElementById('calcFreightStatus');
    const calcEstimatedTotal = document.getElementById('calcEstimatedTotal');
    const calcOrderWhatsAppBtn = document.getElementById('calcOrderWhatsAppBtn');
    const calcAddToCartBtn = document.getElementById('calcAddToCartBtn');

    // Populate calculator products
    if (calcProductSelect) {
        calcProductSelect.innerHTML = PRODUCTS.map(p => `
      <option value="${p.id}">${p.name} (${p.grade})</option>
    `).join('');

        calcProductSelect.addEventListener('change', (e) => {
            state.bulkCalc.productId = e.target.value;
            updateBulkCalculator();
        });
    }

    if (calcWeightSlider) {
        calcWeightSlider.addEventListener('input', (e) => {
            state.bulkCalc.weightKg = parseInt(e.target.value, 10);
            if (calcWeightDisplay) calcWeightDisplay.textContent = `${state.bulkCalc.weightKg} kg`;
            updateBulkCalculator();
        });
    }

    if (calcPackagingSelect) {
        calcPackagingSelect.addEventListener('change', (e) => {
            state.bulkCalc.packaging = e.target.value;
            updateBulkCalculator();
        });
    }

    function getTierForWeight(kg) {
        for (const tier of WHOLESALE_TIERS) {
            if (kg >= tier.minKg && kg <= tier.maxKg) {
                return tier;
            }
        }
        return WHOLESALE_TIERS[WHOLESALE_TIERS.length - 1];
    }

    function updateBulkCalculator() {
        const product = PRODUCTS.find(p => p.id === state.bulkCalc.productId) || PRODUCTS[0];
        const kg = state.bulkCalc.weightKg;
        const tier = getTierForWeight(kg);

        const basePerKg = product.basePrice1kg;
        const rawTotal = basePerKg * kg;
        const discountAmount = Math.round(rawTotal * (tier.discountPercent / 100));
        const finalTotal = rawTotal - discountAmount;

        if (calcSelectedName) calcSelectedName.textContent = product.name;
        if (calcTierBadge) {
            calcTierBadge.textContent = `${tier.tierName} (${tier.badge})`;
        }
        if (calcBaseRate) calcBaseRate.textContent = `₹${basePerKg.toLocaleString('en-IN')} / kg`;
        if (calcTotalKg) calcTotalKg.textContent = `${kg} kg`;
        if (calcDiscountRate) calcDiscountRate.textContent = `${tier.discountPercent}% OFF`;
        if (calcTotalSavings) calcTotalSavings.textContent = `₹${discountAmount.toLocaleString('en-IN')}`;
        if (calcEstimatedTotal) calcEstimatedTotal.textContent = `₹${finalTotal.toLocaleString('en-IN')}`;

        if (calcFreightStatus) {
            if (tier.freeDelivery || kg >= 5) {
                calcFreightStatus.innerHTML = '<i class="fa-solid fa-truck-fast"></i> FREE Express Insured Delivery';
                calcFreightStatus.style.color = '#58b368';
            } else {
                calcFreightStatus.textContent = 'Standard Flat Rate (₹150)';
                calcFreightStatus.style.color = '#9cb0a5';
            }
        }

        // WhatsApp Pre-fill URL
        if (calcOrderWhatsAppBtn) {
            const msg = encodeURIComponent(
                `Hello Caspiora Sales Team, I would like to place a bulk order inquiry:\n\n` +
                `• Product: ${product.name} (${product.grade})\n` +
                `• Quantity: ${kg} kg\n` +
                `• Packaging: ${state.bulkCalc.packaging}\n` +
                `• Applicable Tier: ${tier.tierName} (${tier.discountPercent}% OFF)\n` +
                `• Estimated Quote: ₹${finalTotal.toLocaleString('en-IN')}\n\n` +
                `Please confirm stock availability and freight timeline.`
            );
            calcOrderWhatsAppBtn.onclick = () => {
                window.open(`https://wa.me/919876543210?text=${msg}`, '_blank');
            };
        }

        // Add Bulk to Cart
        if (calcAddToCartBtn) {
            calcAddToCartBtn.onclick = () => {
                addToCart(product, `${kg}kg Bulk`, finalTotal, kg);
            };
        }
    }

    updateBulkCalculator();

    // ========================================================================
    // 5. MASTER PRICING MATRIX TABLE
    // ========================================================================
    const pricingTableBody = document.getElementById('pricingTableBody');
    if (pricingTableBody) {
        pricingTableBody.innerHTML = PRODUCTS.map(p => {
            const masterCartonPerKg = Math.round(p.basePrice1kg * 0.72); // 28% discount for master cartons
            return `
        <tr>
          <td>
            <strong style="color:#ffffff;">${p.name}</strong><br>
            <span style="font-size:0.75rem; color:var(--color-gold);">${p.grade}</span>
          </td>
          <td><span style="text-transform:capitalize;">${p.category}</span></td>
          <td>${p.origin}</td>
          <td>₹${p.basePrice250g.toLocaleString('en-IN')}</td>
          <td>₹${p.basePrice500g.toLocaleString('en-IN')}</td>
          <td><strong style="color:var(--color-gold-light);">₹${p.basePrice1kg.toLocaleString('en-IN')}</strong></td>
          <td>₹${p.basePrice5kg.toLocaleString('en-IN')}</td>
          <td><strong style="color:#58b368;">₹${masterCartonPerKg.toLocaleString('en-IN')} / kg</strong></td>
        </tr>
      `;
        }).join('');
    }

    // ========================================================================
    // 6. FAQS ACCORDION
    // ========================================================================
    const faqContainer = document.getElementById('faqAccordionContainer');
    if (faqContainer && typeof FAQS !== 'undefined') {
        faqContainer.innerHTML = FAQS.map((faq, idx) => `
      <div class="faq-item" style="background:#0f2b22; border:1px solid rgba(229,169,60,0.2); border-radius:var(--radius-md); overflow:hidden;">
        <button class="faq-question-btn" data-faq-index="${idx}" style="width:100%; text-align:left; background:transparent; padding:20px; color:#ffffff; font-weight:600; font-size:1rem; display:flex; justify-content:space-between; align-items:center;">
          <span>${faq.q}</span>
          <i class="fa-solid fa-chevron-down text-gold" style="transition:transform 0.3s ease;"></i>
        </button>
        <div class="faq-answer-panel" id="faq-ans-${idx}" style="max-height:0; overflow:hidden; transition:max-height 0.35s ease; background:rgba(8,26,20,0.5);">
          <p style="padding:0 20px 20px; color:#9cb0a5; font-size:0.92rem; line-height:1.6;">${faq.a}</p>
        </div>
      </div>
    `).join('');

        faqContainer.querySelectorAll('.faq-question-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const idx = e.currentTarget.dataset.faqIndex;
                const panel = document.getElementById(`faq-ans-${idx}`);
                const icon = e.currentTarget.querySelector('i');
                const isOpen = panel.style.maxHeight && panel.style.maxHeight !== '0px';

                // Close all
                faqContainer.querySelectorAll('.faq-answer-panel').forEach(p => p.style.maxHeight = '0px');
                faqContainer.querySelectorAll('.faq-question-btn i').forEach(ic => ic.style.transform = 'rotate(0deg)');

                if (!isOpen) {
                    panel.style.maxHeight = panel.scrollHeight + 'px';
                    icon.style.transform = 'rotate(180deg)';
                }
            });
        });
    }

    // ========================================================================
    // 7. CART DRAWER OPERATIONS
    // ========================================================================
    const cartToggleBtn = document.getElementById('cartToggleBtn');
    const cartOverlay = document.getElementById('cartOverlay');
    const closeCartBtn = document.getElementById('closeCartBtn');
    const cartBadge = document.getElementById('cartBadge');
    const cartCountHeader = document.getElementById('cartCountHeader');
    const cartItemsContainer = document.getElementById('cartItemsContainer');
    const cartSubtotal = document.getElementById('cartSubtotal');
    const checkoutWhatsAppBtn = document.getElementById('checkoutWhatsAppBtn');
    const checkoutQuoteBtn = document.getElementById('checkoutQuoteBtn');

    function updateCartUI() {
        const totalCount = state.cart.reduce((sum, item) => sum + item.quantity, 0);
        const subtotal = state.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

        if (cartBadge) cartBadge.textContent = totalCount;
        if (cartCountHeader) cartCountHeader.textContent = totalCount;
        if (cartSubtotal) cartSubtotal.textContent = `₹${subtotal.toLocaleString('en-IN')}`;

        if (!cartItemsContainer) return;

        if (state.cart.length === 0) {
            cartItemsContainer.innerHTML = `
        <div style="text-align:center; padding:60px 20px; color:#8fa59a;">
          <i class="fa-solid fa-basket-shopping" style="font-size:3.5rem; margin-bottom:16px; opacity:0.4;"></i>
          <p style="font-size:1.1rem; color:#ffffff; margin-bottom:8px;">Your Caspiora Bag is empty</p>
          <p style="font-size:0.85rem;">Discover our royal King Cashews and gourmet nuts to add delicious crunch.</p>
        </div>
      `;
            return;
        }

        cartItemsContainer.innerHTML = state.cart.map((item, index) => `
      <div class="cart-item-card">
        <img src="${item.image}" alt="${item.name}" class="cart-item-img">
        <div class="cart-item-info">
          <div style="display:flex; justify-content:space-between; align-items:flex-start;">
            <h4 class="cart-item-title">${item.name}</h4>
            <button class="remove-item-btn" data-remove-index="${index}" style="background:transparent; color:#8fa59a; font-size:0.9rem;" title="Remove Item">
              <i class="fa-regular fa-trash-can"></i>
            </button>
          </div>
          <div class="cart-item-size">Pack Size: ${item.size}</div>
          <div class="cart-qty-row">
            <div class="qty-controls">
              <button class="qty-btn" data-qty-change="${index}" data-delta="-1">-</button>
              <span style="font-size:0.9rem; font-weight:700; min-width:20px; text-align:center;">${item.quantity}</span>
              <button class="qty-btn" data-qty-change="${index}" data-delta="1">+</button>
            </div>
            <strong style="color:var(--color-gold-light); font-size:1rem;">₹${(item.price * item.quantity).toLocaleString('en-IN')}</strong>
          </div>
        </div>
      </div>
    `).join('');

        // Attach cart item events
        cartItemsContainer.querySelectorAll('[data-qty-change]').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const idx = parseInt(e.currentTarget.dataset.qtyChange, 10);
                const delta = parseInt(e.currentTarget.dataset.delta, 10);
                state.cart[idx].quantity += delta;
                if (state.cart[idx].quantity <= 0) {
                    state.cart.splice(idx, 1);
                }
                saveCart();
                updateCartUI();
            });
        });

        cartItemsContainer.querySelectorAll('[data-remove-index]').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const idx = parseInt(e.currentTarget.dataset.removeIndex, 10);
                state.cart.splice(idx, 1);
                saveCart();
                updateCartUI();
            });
        });
    }

    function saveCart() {
        try {
            localStorage.setItem('caspiora_cart', JSON.stringify(state.cart));
        } catch (e) {
            // Ignore
        }
    }

    function addToCart(product, size, customPrice = null, customQty = 1) {
        const price = customPrice !== null ? customPrice : getPriceForProduct(product, size);
        const existingIndex = state.cart.findIndex(i => i.id === product.id && i.size === size);

        if (existingIndex > -1) {
            state.cart[existingIndex].quantity += customQty;
        } else {
            state.cart.push({
                id: product.id,
                name: product.name,
                size: size,
                price: price,
                image: product.image,
                quantity: customQty
            });
        }

        saveCart();
        updateCartUI();
        showToast(`Added ${product.name} (${size}) to your bag!`);
        openCart();
    }

    function openCart() {
        if (cartOverlay) cartOverlay.classList.add('open');
    }

    function closeCart() {
        if (cartOverlay) cartOverlay.classList.remove('open');
    }

    if (cartToggleBtn) cartToggleBtn.addEventListener('click', openCart);
    if (closeCartBtn) closeCartBtn.addEventListener('click', closeCart);
    if (cartOverlay) {
        cartOverlay.addEventListener('click', (e) => {
            if (e.target === cartOverlay) closeCart();
        });
    }

    // Checkout via WhatsApp
    if (checkoutWhatsAppBtn) {
        checkoutWhatsAppBtn.addEventListener('click', () => {
            if (state.cart.length === 0) {
                showToast('Your bag is currently empty!');
                return;
            }

            const itemsList = state.cart.map(i => `• ${i.name} [${i.size}] x ${i.quantity} = ₹${(i.price * i.quantity).toLocaleString('en-IN')}`).join('\n');
            const subtotal = state.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

            const msg = encodeURIComponent(
                `Hello Caspiora, I would like to place the following order:\n\n` +
                `${itemsList}\n\n` +
                `Total Payable: ₹${subtotal.toLocaleString('en-IN')}\n\n` +
                `Please send dispatch confirmation and payment link.`
            );

            window.open(`https://wa.me/919876543210?text=${msg}`, '_blank');
        });
    }

    // Print / Download summary
    if (checkoutQuoteBtn) {
        checkoutQuoteBtn.addEventListener('click', () => {
            if (state.cart.length === 0) {
                showToast('Your bag is empty!');
                return;
            }
            window.print();
        });
    }

    updateCartUI();

    // ========================================================================
    // 8. QUICK VIEW MODAL
    // ========================================================================
    const quickViewModal = document.getElementById('quickViewModal');
    const closeModalBtn = document.getElementById('closeModalBtn');
    const modalImg = document.getElementById('modalImg');
    const modalGradeBadge = document.getElementById('modalGradeBadge');
    const modalTitle = document.getElementById('modalTitle');
    const modalOrigin = document.getElementById('modalOrigin');
    const modalDesc = document.getElementById('modalDesc');
    const modalNutrition = document.getElementById('modalNutrition');
    const modalPrice = document.getElementById('modalPrice');
    const modalAddToCartBtn = document.getElementById('modalAddToCartBtn');

    let activeModalProduct = null;

    function openQuickViewModal(product) {
        activeModalProduct = product;
        if (modalImg) {
            modalImg.onerror = function() {
                this.onerror = null;
                if (this.src.endsWith('.png')) this.src = this.src.replace('.png', '.jpg');
            };
            modalImg.src = product.image;
        }
        if (modalGradeBadge) modalGradeBadge.textContent = product.grade;
        if (modalTitle) modalTitle.textContent = product.name;
        if (modalOrigin) modalOrigin.innerHTML = `<i class="fa-solid fa-location-dot"></i> Origin: ${product.origin} | Spec: ${product.specs.processing}`;
        if (modalDesc) modalDesc.textContent = product.description;

        if (modalNutrition && product.nutrition) {
            modalNutrition.innerHTML = `
        <div><strong>Calories:</strong> ${product.nutrition.calories}</div>
        <div><strong>Protein:</strong> ${product.nutrition.protein}</div>
        <div><strong>Healthy Fats:</strong> ${product.nutrition.healthyFats}</div>
        <div><strong>Carbs:</strong> ${product.nutrition.carbs}</div>
      `;
        }

        if (modalPrice) modalPrice.textContent = `₹${product.basePrice500g.toLocaleString('en-IN')}`;

        if (quickViewModal) quickViewModal.classList.add('open');
    }

    function closeQuickViewModal() {
        if (quickViewModal) quickViewModal.classList.remove('open');
        activeModalProduct = null;
    }

    if (closeModalBtn) closeModalBtn.addEventListener('click', closeQuickViewModal);
    if (quickViewModal) {
        quickViewModal.addEventListener('click', (e) => {
            if (e.target === quickViewModal) closeQuickViewModal();
        });
    }

    if (modalAddToCartBtn) {
        modalAddToCartBtn.addEventListener('click', () => {
            if (activeModalProduct) {
                addToCart(activeModalProduct, '500g');
                closeQuickViewModal();
            }
        });
    }

    // ========================================================================
    // 9. CONTACT FORM HANDLER
    // ========================================================================
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const name = document.getElementById('contactName').value.trim();
            const phone = document.getElementById('contactPhone').value.trim();
            const email = document.getElementById('contactEmail').value.trim();
            const type = document.getElementById('contactInquiryType').value;
            const product = document.getElementById('contactProduct').value;
            const msg = document.getElementById('contactMessage').value.trim();

            showToast(`Thank you ${name}! Your inquiry has been registered.`);

            // Prompt to continue on WhatsApp
            const waMsg = encodeURIComponent(
                `Hello Caspiora Team, inquiry submitted by ${name} (${email}, ${phone}):\n\n` +
                `• Inquiry Type: ${type}\n` +
                `• Product Interest: ${product}\n` +
                `• Notes: ${msg}`
            );

            setTimeout(() => {
                if (confirm('Would you like to open WhatsApp to connect directly with the Caspiora bulk sales desk right away?')) {
                    window.open(`https://wa.me/919876543210?text=${waMsg}`, '_blank');
                }
            }, 500);

            contactForm.reset();
        });
    }

    // ========================================================================
    // 10. TOAST NOTIFICATION UTILITY
    // ========================================================================
    function showToast(message) {
        const toastNotice = document.getElementById('toastNotice');
        const toastMsg = document.getElementById('toastMsg');
        if (!toastNotice || !toastMsg) return;

        toastMsg.textContent = message;
        toastNotice.classList.add('show');

        setTimeout(() => {
            toastNotice.classList.remove('show');
        }, 3800);
    }

    // Mobile navigation menu toggle
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const navMenu = document.getElementById('navMenu');
    if (mobileMenuBtn && navMenu) {
        mobileMenuBtn.addEventListener('click', () => {
            const isVisible = navMenu.style.display === 'flex';
            navMenu.style.display = isVisible ? 'none' : 'flex';
            navMenu.style.flexDirection = 'column';
            navMenu.style.position = 'absolute';
            navMenu.style.top = '80px';
            navMenu.style.left = '0';
            navMenu.style.width = '100%';
            navMenu.style.background = '#081a14';
            navMenu.style.padding = '20px';
            navMenu.style.borderBottom = '1px solid var(--color-card-border)';
        });
    }
});
